import mod from "./index.js";

export default mod;
export const FingerprintInjector = mod.FingerprintInjector;
